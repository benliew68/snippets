return {
  {
    "akinsho/toggleterm.nvim",
    version = "*",
    config = function()
      require('toggleterm').setup {
        -- shade_terminals = false,
        persist_mode = true,
        winbar = {
          enabled = false,
        },
        terminal_mappings = true,
        insert_mappings = true,
        open_mapping = [[<A-h>]]
      }
    end,
  },
}
